import json
import numpy as np
import tensorflow.keras as keras
from preprocess import SEQUENCE_LENGTH, MAPPING_PATH
class MelodyGenerator:
    """A class that wraps the LSTM model and offers utilities to generate melodies."""

    def __init__(self,
                 model_path=r"C:\Users\SIREESHA\Desktop\generating-melodies-with-rnn-lstm-master\generating-melodies-with-rnn-lstm-master\5-training the network\model.h5"):

        self.model_path = model_path
        self.model = keras.models.load_model(model_path)

        try:
            with open(MAPPING_PATH, "r") as fp:
                self._mappings = json.load(fp)
                print("Mappings Loaded Successfully:", self._mappings)

            if not self._mappings:
                raise ValueError("Error: Mapping file is empty!")

        except Exception as e:
            print(f"Error loading mappings: {e}")
            self._mappings = {}  # Fallback

        self._start_symbols = ["/"] * SEQUENCE_LENGTH


    def generate_melody(self, seed, num_steps, max_sequence_length, temperature):
        """Generates a melody using the DL model and returns a midi file.

        # create seed with start symbols
        seed = seed.split()
        melody = seed
        seed = self._start_symbols + seed

        # map seed to int
        seed = [self._mappings[symbol] if symbol in self._mappings else self._mappings["unknown"] for symbol in seed]

        for _ in range(num_steps):

            # limit the seed to max_sequence_length
            seed = seed[-max_sequence_length:]

            # one-hot encode the seed
            num_classes = self.model.input_shape[-1]  # Get correct vocab size from model
            onehot_seed = keras.utils.to_categorical(seed, num_classes=num_classes)

            # (1, max_sequence_length, num of symbols in the vocabulary)
            onehot_seed = onehot_seed[np.newaxis, ...]

            # make a prediction
            probabilities = self.model.predict(onehot_seed)[0]
            # [0.1, 0.2, 0.1, 0.6] -> 1
            output_int = self._sample_with_temperature(probabilities, temperature)

            # update seed
            seed.append(output_int)

            # map int to our encoding
            output_symbol = [k for k, v in self._mappings.items() if v == output_int][0]

            # check whether we're at the end of a melody
            if output_symbol == "/":
                break

            # update melody
            melody.append(output_symbol)

        return melody


    def _sample_with_temperature(self, probabilites, temperature):
        """Samples an index from a probability array reapplying softmax using temperature

        :param predictions (nd.array): Array containing probabilities for each of the possible outputs.
        :param temperature (float): Float in interval [0, 1]. Numbers closer to 0 make the model more deterministic.
            A number closer to 1 makes the generation more unpredictable.

        :return index (int): Selected output symbol
        """
        predictions = np.log(probabilites) / temperature
        probabilites = np.exp(predictions) / np.sum(np.exp(predictions))

        choices = range(len(probabilites)) # [0, 1, 2, 3]
        index = np.random.choice(choices, p=probabilites)

        return index


if __name__ == "__main__":
    mg = MelodyGenerator()
    seed = "55 _ _ _ 60 _ _ _ 55 _ _ _ 55 _"
    melody = mg.generate_melody(seed, 500, SEQUENCE_LENGTH, 0.7)
    print(melody)




















