import os
import json
import music21 as m21
import numpy as np
import tensorflow.keras as keras

# Paths
KERN_DATASET_PATH = r"C:\Users\SIREESHA\Desktop\generating-melodies-with-rnn-lstm-master\1-dataset transposition filtering\code\deutschl"
SAVE_DIR = "dataset"
SINGLE_FILE_DATASET = "file_dataset"
MAPPING_PATH = r"C:\Users\SIREESHA\Desktop\generating-melodies-with-rnn-lstm-master\mapping.json"

SEQUENCE_LENGTH = 64
MAX_TRAINING_SAMPLES = 500000  # Limit dataset size

# Acceptable note durations (quarter lengths)
ACCEPTABLE_DURATIONS = [0.25, 0.5, 0.75, 1.0, 1.5, 2, 3, 4]


def load_songs_in_kern(dataset_path):
    """Loads all .krn songs from the dataset path."""
    songs = []
    for path, _, files in os.walk(dataset_path):
        for file in files:
            if file.endswith(".krn"):
                try:
                    song = m21.converter.parse(os.path.join(path, file))
                    songs.append(song)
                except Exception as e:
                    print(f"Skipping {file} due to parsing error: {e}")
    return songs


def has_acceptable_durations(song):
    """Checks if all notes/rests in the song have acceptable durations."""
    return all(note.duration.quarterLength in ACCEPTABLE_DURATIONS for note in song.flat.notesAndRests)


def transpose(song):
    """Transposes song to C major or A minor."""
    parts = song.getElementsByClass(m21.stream.Part)
    measures_part0 = parts[0].getElementsByClass(m21.stream.Measure)
    key = measures_part0[0][4]

    # Estimate key if not found
    if not isinstance(key, m21.key.Key):
        key = song.analyze("key")

    # Determine transposition interval
    interval = m21.interval.Interval(key.tonic, m21.pitch.Pitch("C")) if key.mode == "major" else \
        m21.interval.Interval(key.tonic, m21.pitch.Pitch("A"))

    return song.transpose(interval)


def encode_song(song, time_step=0.25):
    """Encodes a song into a sequence of musical symbols."""
    encoded_song = []
    for event in song.flat.notesAndRests:
        symbol = event.pitch.midi if isinstance(event, m21.note.Note) else "r"
        steps = int(event.duration.quarterLength / time_step)
        encoded_song.extend([symbol if step == 0 else "_" for step in range(steps)])

    return " ".join(map(str, encoded_song))


def preprocess(dataset_path):
    """Preprocesses dataset: filters, transposes, encodes, and saves songs."""
    os.makedirs(SAVE_DIR, exist_ok=True)
    songs = load_songs_in_kern(dataset_path)

    for i, song in enumerate(songs):
        if not has_acceptable_durations(song):
            continue
        encoded_song = encode_song(transpose(song))
        with open(os.path.join(SAVE_DIR, str(i)), "w") as fp:
            fp.write(encoded_song)
        if i % 10 == 0:
            print(f"Processed {i}/{len(songs)} songs")


def load(file_path):
    """Loads a song from a file."""
    with open(file_path, "r") as fp:
        return fp.read()


def create_single_file_dataset(dataset_path, file_dataset_path, sequence_length):
    """Creates a single file containing all encoded songs with delimiters."""
    new_song_delimiter = "/ " * sequence_length
    songs = " ".join(load(os.path.join(path, file)) + " " + new_song_delimiter
                     for path, _, files in os.walk(dataset_path) for file in files)
    with open(file_dataset_path, "w") as fp:
        fp.write(songs[:-1])  # Remove trailing space
    return songs


def create_mapping(songs, mapping_path):
    """Creates a mapping of symbols to integers."""
    mappings = {symbol: i for i, symbol in enumerate(set(songs.split()))}
    with open(mapping_path, "w") as fp:
        json.dump(mappings, fp, indent=4)


def convert_songs_to_int(songs):
    """Converts songs to integer sequences based on mapping."""
    with open(MAPPING_PATH, "r") as fp:
        mappings = json.load(fp)
    return [mappings[symbol] for symbol in songs.split()]
mapping = {}  # Initialize an empty dictionary

def create_mapping(songs, mapping_path):
    """Creates a mapping of symbols to integers."""
    global mapping
    unique_tokens = set(songs.split())  # Extract unique tokens
    mapping = {token: index for index, token in enumerate(unique_tokens)}

    with open(mapping_path, "w") as fp:
        json.dump(mapping, fp, indent=4)

# Call create_mapping() somewhere before generate_training_sequences()


def generate_training_sequences(sequence_length):
    """Generates training sequences for model training."""

    # Ensure mapping is loaded
    global mapping
    if not mapping:
        try:
            with open(MAPPING_PATH, "r") as fp:
                mapping = json.load(fp)
        except FileNotFoundError:
            raise ValueError("Error: 'mapping.json' not found. Run create_mapping() first.")

    int_songs = convert_songs_to_int(load(SINGLE_FILE_DATASET))[:MAX_TRAINING_SAMPLES]
    inputs = [int_songs[i:i + sequence_length] for i in range(len(int_songs) - sequence_length)]
    targets = [int_songs[i + sequence_length] for i in range(len(int_songs) - sequence_length)]

    return np.array(inputs), np.array(targets), len(mapping)


def main():
    preprocess(KERN_DATASET_PATH)
    songs = create_single_file_dataset(SAVE_DIR, SINGLE_FILE_DATASET, SEQUENCE_LENGTH)

    # Ensure mapping is created and saved before training
    create_mapping(songs, MAPPING_PATH)


if __name__ == "__main__":
    main()
