import tensorflow.keras as keras
from preprocess import generate_training_sequences, SEQUENCE_LENGTH

# Hyperparameters
OUTPUT_UNITS = 40 # Replace with the actual vocabulary size

NUM_UNITS = [256]
LOSS = "sparse_categorical_crossentropy"
LEARNING_RATE = 0.001
EPOCHS = 50
BATCH_SIZE = 64
SAVE_MODEL_PATH = "model.h5"


def build_model(output_units, num_units, loss, learning_rate):
    """Builds and compiles the LSTM model."""

    input_layer = keras.layers.Input(shape=(None,))
    x = keras.layers.Embedding(input_dim=output_units, output_dim=256)(input_layer)
    x = keras.layers.LSTM(num_units[0])(x)
    x = keras.layers.Dropout(0.2)(x)
    output_layer = keras.layers.Dense(output_units, activation="softmax")(x)

    model = keras.Model(input_layer, output_layer)
    model.compile(loss=loss, optimizer=keras.optimizers.Adam(learning_rate=learning_rate), metrics=["accuracy"])
    model.summary()
    return model


def train():
    """Trains the LSTM model."""
    inputs, targets, vocab_size = generate_training_sequences(SEQUENCE_LENGTH)  # Get vocab size dynamically

    model = build_model(vocab_size, NUM_UNITS, LOSS, LEARNING_RATE)  # Use correct vocab size
    model.fit(inputs, targets, epochs=EPOCHS, batch_size=BATCH_SIZE)
    model.save(SAVE_MODEL_PATH)



if __name__ == "__main__":
    train()
