# 🎵 Music Generation Using RNN-Based LSTM

This project demonstrates the use of **Recurrent Neural Networks (RNNs)**, specifically **Long Short-Term Memory (LSTM)** networks, to generate coherent and creative music sequences. It highlights how deep learning can be applied in creative domains like music composition by learning from symbolic musical datasets.

---

## 📌 Project Objective

To train an LSTM-based neural network on encoded musical compositions and enable it to generate new music that maintains stylistic and structural integrity similar to the input data.

---

## ✅ Features

- Converts MIDI files to encoded symbolic data using `music21`
- Preprocesses, transposes, and encodes melodies
- Builds and trains an LSTM model to predict musical sequences
- Generates music from a seed melody using temperature-based sampling
- Saves output as **MIDI** and **MusicXML** for playback in MuseScore
- GUI built with **Tkinter** for easy user interaction

---

## ⚙️ Technologies Used

- **Python**
- **TensorFlow / Keras**
- **NumPy, Pandas**
- **music21** – for music parsing and processing
- **MuseScore 4** – for playing and visualizing generated music
- **Tkinter** – for building the GUI

---

## 📂 Project Structure

```
├── dataset/                  # Encoded and transposed song data
├── mapping.json             # Symbol-to-integer map for melody
├── model.h5                 # Trained LSTM model
├── melodygenerator.py       # Melody generation class
├── gui.py                   # GUI application to interact with generator
├── preprocess.py            # Preprocessing logic for dataset
├── train.py                 # LSTM model architecture and training
└── README.md
```

---

## 🎼 Dataset

- MIDI files sourced from the **ESAC** dataset and traditional folk song archives.
- Encoded using **music21** with duration, note, and chord details.
- Transposed to a common key (C major or A minor) for uniformity.
- Sequences split and one-hot encoded for model input.

---

## 🧠 Model Overview

- Two LSTM layers with dropout
- Dense softmax output layer
- Trained using **sparse categorical cross-entropy** and **Adam optimizer**
- Supports generation via **temperature-controlled sampling**

---

## 💻 How to Run

1. Run `preprocess.py` to process and encode musical data.
2. Run `train.py` to train the LSTM model and save it as `model.h5`.
3. Launch the GUI using `gui.py`:
   ```bash
   python gui.py
   ```
4. Enter a **seed melody**, set **length** and **temperature**, and click **Generate** to hear music!

---

## 📷 GUI Features

- Seed melody input box  
- Sequence length & temperature fields  
- View generated notes  
- Play output via MuseScore  

---

## 📊 Evaluation

- Evaluated on musical coherence, creativity, and flow
- Qualitative assessment based on human feedback and playback
- Demonstrates ability to retain structure while producing novel outputs

---

## 🔮 Future Scope

- Integrate **Transformers** and **GANs** for more advanced generation
- Add **multimodal data**: lyrics, genre, user mood
- Develop **interactive music generation apps**
- Explore **VR/AR** use cases with AI-generated soundtracks

---

## 👨‍💻 Contributors

- A. Sai Sireesha (N190035)  
- V. Asha Jyothi (N190075)  
- P. Percy Parimila (N190310)  
- P. Alekhya (N190755)  
- P. M. N. Sirisha (N191056)  

**Guide:** Mr. R. Siva Narayana (Assistant Professor, RGUKT-Nuzvid)

---

## 📅 Duration

**Academic Year:** November 2024 – April 2025  
**Institution:** Rajiv Gandhi University of Knowledge Technologies, Nuzvid

---

## 📜 License

This project is created for educational purposes only and is not intended for commercial use.
