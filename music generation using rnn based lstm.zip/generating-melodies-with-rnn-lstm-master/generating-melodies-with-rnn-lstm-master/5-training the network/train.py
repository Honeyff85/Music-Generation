import tensorflow.keras as keras
from preprocess import generate_training_sequences, SEQUENCE_LENGTH

OUTPUT_UNITS = 38
NUM_UNITS = [256]
LOSS = "sparse_categorical_crossentropy"
LEARNING_RATE = 0.001
EPOCHS = 50
BATCH_SIZE = 64
SAVE_MODEL_PATH = "model.h5"


def build_model(output_units, num_units, loss, learning_rate):
    # create the model architecture
    inputs = keras.layers.Input(shape=(None, output_units))  # Renamed `input` to `inputs`
    x = keras.layers.LSTM(num_units[0])(inputs)
    x = keras.layers.Dropout(0.2)(x)
    output = keras.layers.Dense(output_units, activation="softmax")(x)  # Fixed missing `)`

    model = keras.Model(inputs, output)  # Renamed `input` to `inputs`

    # compile model
    model.compile(loss=loss,
                  optimizer=keras.optimizers.Adam(learning_rate=learning_rate),
                  metrics=["accuracy"])

    model.summary()
    return model


def train(output_units=OUTPUT_UNITS, num_units=NUM_UNITS, loss=LOSS, learning_rate=LEARNING_RATE):
    # generate the training sequences
    sequence_generator = generate_training_sequences(SEQUENCE_LENGTH, BATCH_SIZE)

    # build the network
    model = build_model(output_units, num_units, loss, learning_rate)

    # train the model
    model.fit(sequence_generator, steps_per_epoch=100, epochs=EPOCHS)

    # save the model
    model.save(SAVE_MODEL_PATH)


if __name__ == "__main__":
    train()
