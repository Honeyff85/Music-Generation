import json
import numpy as np
from tensorflow import keras
import music21 as m21
from preprocess import SEQUENCE_LENGTH, MAPPING_PATH

class MelodyGenerator:
    def __init__(self, model_path="model.h5"):
        self.model_path = model_path
        self.model = keras.models.load_model(model_path)
        with open(MAPPING_PATH, "r") as fp:
            self._mappings = json.load(fp)

        self._start_symbols = ["/"] * SEQUENCE_LENGTH
        self.num_classes = self.model.input_shape[-1]

    def generate_melody(self, seed, num_steps, max_sequence_length, temperature):
        seed = seed.split()
        melody = seed.copy()
        seed = self._start_symbols + seed
        try:
            seed = [self._mappings[symbol] for symbol in seed]
        except KeyError as e:
            print(f"Error: Symbol '{e.args[0]}' not found in mappings. Check your dataset.")
            return []

        for _ in range(num_steps):
            seed = seed[-max_sequence_length:] #slicing from end
            input_seed = np.array(seed).reshape(1, SEQUENCE_LENGTH)
            probabilities = self.model.predict(input_seed, verbose=0)[0]
            output_int = self._sample_with_temperature(probabilities, temperature)
            if output_int >= self.num_classes:
                print(f"Warning: Generated index {output_int} exceeds num_classes ({self.num_classes}). Skipping.")
                continue

            seed.append(output_int)
            output_symbol = next((k for k, v in self._mappings.items() if v == output_int), None)
            if output_symbol is None:
                print(f"Warning: Generated index {output_int} not found in mappings.")
                continue

            if output_symbol == "/":
                break

            melody.append(output_symbol)
        return melody

    def _sample_with_temperature(self, probabilities, temperature):
        predictions = np.log(probabilities + 1e-9) / temperature
        probabilities = np.exp(predictions) / np.sum(np.exp(predictions))
        return np.random.choice(range(len(probabilities)), p=probabilities)

    def save_melody(self, melody, step_duration=0.25, format="midi", file_name="mel.mid"):
        stream = m21.stream.Stream()
        start_symbol = None
        step_counter = 1
        for i, symbol in enumerate(melody):
            if symbol != "_" or i + 1 == len(melody):
                if start_symbol is not None:
                    duration = step_duration * step_counter
                    try:
                        m21_event = m21.note.Rest(quarterLength=duration) if start_symbol == "r" else m21.note.Note(
                            int(start_symbol), quarterLength=duration)
                        stream.append(m21_event)
                    except ValueError:
                        print(f"Warning: Invalid note '{start_symbol}', skipping.")
                    step_counter = 1
                start_symbol = symbol
            else:
                step_counter += 1
        stream.write(format, file_name)

if __name__ == "__main__":
    mg = MelodyGenerator()
    seed = "67 _ 67 _ 67 _ _ 65 64 _ 64 _ 64 _ _"
    melody = mg.generate_melody(seed, 1000, SEQUENCE_LENGTH, 0.3)
    if melody:
        print(melody)
        mg.save_melody(melody)
