import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import os
from melodygenerator import MelodyGenerator
import music21 as m21

# Set MuseScore path
us = m21.environment.UserSettings()
us['musicxmlPath'] = r"C:\Program Files\MuseScore 4\bin\MuseScore4.exe"

class MelodyApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Melody Generator 🎵")
        self.root.geometry("800x800")

        # Background Image
        self.bg_image = tk.PhotoImage(file=r"C:\Users\SIREESHA\Downloads\bg.png")
        self.canvas = tk.Canvas(root, width=800, height=800)
        self.canvas.create_image(0, 0, image=self.bg_image, anchor="nw")
        self.canvas.pack(fill="both", expand=True)

        # Style Configuration
        style = ttk.Style()
        style.configure("TFrame", background="#ffffff")
        style.configure("TLabel", background="#ffffff", font=("Segoe UI", 12))
        style.configure("TButton", font=("Segoe UI", 11, "bold"), foreground="#ffffff", background="#5C67F2")
        style.map("TButton", background=[("active", "#4A54E1")])

        # Main Frame
        self.main_frame = ttk.Frame(root, padding=30, style="TFrame")
        self.main_frame.place(relx=0.5, rely=0.5, anchor="center")

        # Input Labels & Fields
        self.label = ttk.Label(self.main_frame, text="🎼 Enter Seed Melody:", foreground="#2E86C1")
        self.label.pack(pady=8)

        self.text_edit = scrolledtext.ScrolledText(self.main_frame, height=5, width=60, font=("Arial", 11))
        self.text_edit.pack(pady=5)

        self.length_label = ttk.Label(self.main_frame, text="📏 Enter Sequence Length:", foreground="#D35400")
        self.length_label.pack(pady=8)

        self.length_entry = ttk.Entry(self.main_frame, font=("Arial", 11), width=15)
        self.length_entry.insert(0, "500")
        self.length_entry.pack(pady=5)

        self.temp_label = ttk.Label(self.main_frame, text="🔥 Enter Temperature:", foreground="#E74C3C")
        self.temp_label.pack(pady=8)

        self.temp_entry = ttk.Entry(self.main_frame, font=("Arial", 11), width=15)
        self.temp_entry.insert(0, "0.3")
        self.temp_entry.pack(pady=5)

        # Generate Melody Button
        self.generate_button = ttk.Button(self.main_frame, text="🎶 Generate Melody", command=self.generate_melody)
        self.generate_button.pack(pady=15)

        self.generated_label = ttk.Label(self.main_frame, text="🎵 Generated Sequence:", foreground="#27AE60")
        self.generated_label.pack(pady=8)

        self.generated_text = scrolledtext.ScrolledText(self.main_frame, height=5, width=60, font=("Arial", 11))
        self.generated_text.pack(pady=5)

        # Play Button
        self.play_button = ttk.Button(self.main_frame, text="▶️ Play in MuseScore", command=self.play_melody)
        self.play_button.pack(pady=15)

        # Melody generator object
        self.generated_melody = None
        self.generator = MelodyGenerator()

    def generate_melody(self):
        seed = self.text_edit.get("1.0", "end-1c").strip()
        try:
            num_steps = int(self.length_entry.get())
            temperature = float(self.temp_entry.get())
        except ValueError:
            messagebox.showerror("Invalid Input", "Please enter valid numbers for length and temperature.")
            return

        melody = self.generator.generate_melody(seed, num_steps, self.generator.model.input_shape[1], temperature)

        if melody:
            self.generated_melody = melody
            self.generated_text.delete("1.0", tk.END)
            self.generated_text.insert(tk.END, " ".join(melody))
            self.generator.save_melody(melody, format="musicxml", file_name="melody.xml")
        else:
            messagebox.showerror("Generation Failed", "Something went wrong during melody generation.")

    def play_melody(self):
        if self.generated_melody:
            try:
                stream = m21.converter.parse("melody.xml")
                stream.show()  # Opens MuseScore
            except Exception as e:
                messagebox.showerror("MuseScore Error", f"Could not open MuseScore.\n{e}")
        else:
            messagebox.showinfo("No Melody", "Please generate a melody first.")


if __name__ == "__main__":
    root = tk.Tk()
    app = MelodyApp(root)
    root.mainloop()
