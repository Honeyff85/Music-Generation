import numpy as np
import tensorflow as tf
import tensorflow.keras as keras
from preprocess import generate_training_sequences, SEQUENCE_LENGTH

OUTPUT_UNITS = 50
NUM_UNITS = [128]
LOSS = "sparse_categorical_crossentropy"
LEARNING_RATE = 0.001
EPOCHS = 50
BATCH_SIZE = 32
SAVE_MODEL_PATH = "model.h5"
MAX_TRAINING_SAMPLES = 200000

def build_model(output_units, num_units, loss, learning_rate):
    input_layer = keras.layers.Input(shape=(SEQUENCE_LENGTH,))
    x = keras.layers.Embedding(output_units, 64, input_length=SEQUENCE_LENGTH)(input_layer)
    x = keras.layers.LSTM(num_units[0], return_sequences=True)(x)
    x = keras.layers.LSTM(num_units[0])(x)
    x = keras.layers.Dropout(0.2)(x)
    output_layer = keras.layers.Dense(output_units, activation="softmax")(x)
    model = keras.Model(input_layer, output_layer)
    model.compile(loss=loss, optimizer=keras.optimizers.Adam(learning_rate), metrics=["accuracy"])
    model.summary()
    return model

def train():
    inputs, targets = generate_training_sequences(SEQUENCE_LENGTH)
    # Dynamically set OUTPUT_UNITS
    global OUTPUT_UNITS
    OUTPUT_UNITS = np.max(inputs) + 1
    print(f"Final OUTPUT_UNITS: {OUTPUT_UNITS}")
    inputs = inputs[:MAX_TRAINING_SAMPLES]
    targets = targets[:MAX_TRAINING_SAMPLES]
    print(f"Training on {len(inputs)} samples...")

    dataset = tf.data.Dataset.from_tensor_slices((inputs, targets))
    dataset = dataset.batch(BATCH_SIZE).shuffle(10000).prefetch(tf.data.experimental.AUTOTUNE)

    model = build_model(OUTPUT_UNITS, NUM_UNITS, LOSS, LEARNING_RATE)
    model.fit(dataset, epochs=EPOCHS)

    model.save(SAVE_MODEL_PATH)

if __name__ == "__main__":
    train()
