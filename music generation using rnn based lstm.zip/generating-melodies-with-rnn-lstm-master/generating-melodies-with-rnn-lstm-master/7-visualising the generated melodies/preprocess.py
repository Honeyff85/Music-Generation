import os
import json
import music21 as m21
import numpy as np
import tensorflow.keras as keras

KERN_DATASET_PATH = r"C:\Users\SIREESHA\Desktop\generating-melodies-with-rnn-lstm-master\generating-melodies-with-rnn-lstm-master\1-dataset transposition filtering\code\deutschl"
SAVE_DIR = "dataset"
SINGLE_FILE_DATASET = "file_dataset"
MAPPING_PATH = "mapping.json"
SEQUENCE_LENGTH = 64
ACCEPTABLE_DURATIONS = [0.25, 0.5, 0.75, 1.0, 1.5, 2, 3, 4]

def load_songs_in_kern(dataset_path):
    songs = []
    for path, _, files in os.walk(dataset_path):
        for file in files:
            if file.endswith(".krn"):
                file_path = os.path.join(path, file)
                try:
                    song = m21.converter.parse(file_path)
                    songs.append(song)
                except Exception as e:
                    print(f"Error loading {file_path}: {e}")
    return songs

def has_acceptable_durations(song, acceptable_durations):
    return all(note.duration.quarterLength in acceptable_durations for note in song.flat.notesAndRests)

def transpose(song):
    try:
        key = song.analyze("key")
        if key.mode == "major":
            interval = m21.interval.Interval(key.tonic, m21.pitch.Pitch("C"))
        else:
            interval = m21.interval.Interval(key.tonic, m21.pitch.Pitch("A"))
        return song.transpose(interval)
    except Exception as e:
        print(f"Error transposing song: {e}")
        return song

def encode_song(song, time_step=0.25):
    encoded_song = []
    for event in song.flat.notesAndRests:
        symbol = event.pitch.midi if isinstance(event, m21.note.Note) else "r"
        steps = int(event.duration.quarterLength / time_step)
        encoded_song.extend([symbol] + ["_"] * (steps - 1))
    return " ".join(map(str, encoded_song))

def preprocess(dataset_path):
    print("Loading songs...")
    songs = load_songs_in_kern(dataset_path)
    print(f"Loaded {len(songs)} songs.")

    if not os.path.exists(SAVE_DIR):
        os.makedirs(SAVE_DIR)

    for i, song in enumerate(songs):
        if has_acceptable_durations(song, ACCEPTABLE_DURATIONS):
            song = transpose(song)
            encoded_song = encode_song(song)
            with open(os.path.join(SAVE_DIR, str(i)), "w") as fp:
                fp.write(encoded_song)
            if i % 10 == 0:
                print(f"Processed {i}/{len(songs)} songs.")

def load(file_path):
    with open(file_path, "r") as fp:
        return fp.read()

def create_single_file_dataset(dataset_path, output_file, sequence_length):
    all_songs = ""
    for file in os.listdir(dataset_path):
        file_path = os.path.join(dataset_path, file)
        song = load(file_path)
        all_songs += song + " / "

    all_songs = all_songs.strip(" / ")
    with open(output_file, "w") as fp:
        fp.write(all_songs)
    return all_songs


def create_mapping(songs, mapping_path):

    vocabulary = list(set(songs.split()))
    mappings = {symbol: i for i, symbol in enumerate(vocabulary)}

    with open(mapping_path, "w") as fp:
        json.dump(mappings, fp, indent=4)


def convert_songs_to_int(songs):
    with open(MAPPING_PATH, "r") as fp:
        mappings = json.load(fp)
    OUTPUT_UNITS = len(mappings)
    int_songs = [mappings[symbol] for symbol in songs.split() if symbol in mappings]
    int_songs = [min(i, OUTPUT_UNITS - 1) for i in int_songs]
    return int_songs

def generate_training_sequences(sequence_length):
    songs = load(SINGLE_FILE_DATASET)
    int_songs = convert_songs_to_int(songs)
    # Ensure OUTPUT_UNITS covers all possible token values
    global OUTPUT_UNITS
    OUTPUT_UNITS = np.max(int_songs) + 1
    inputs, targets = [], []
    num_sequences = len(int_songs) - sequence_length
    for i in range(num_sequences):
        inputs.append(int_songs[i:i+sequence_length])
        targets.append(int_songs[i+sequence_length])

    inputs = np.array(inputs, dtype=np.uint8)
    targets = np.array(targets, dtype=np.uint8)

    print(f"Shape before one-hot encoding: {inputs.shape}")
    print(f"Updated OUTPUT_UNITS: {OUTPUT_UNITS}")

    return inputs, targets

def main():
    preprocess(KERN_DATASET_PATH)
    songs = create_single_file_dataset(SAVE_DIR, SINGLE_FILE_DATASET, SEQUENCE_LENGTH)
    create_mapping(songs, MAPPING_PATH)


if __name__ == "__main__":
    main()
